#pragma once
//#include "STD_TYPES.h"
void aes_enc_dec(char* state, char* key, char dir);
